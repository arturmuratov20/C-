﻿using SharpEcho.Recruiting.SpellChecker.Contracts;
using System;
using System.IO;
using System.Net;

namespace SharpEcho.Recruiting.SpellChecker.Core
{
    /// <summary>
    /// This is a dictionary based spell checker that uses dictionary.com to determine if
    /// a word is spelled correctly
    /// 
    /// The URL to do this looks like this: http://dictionary.reference.com/browse/<word>
    /// where <word> is the word to be checked
    /// 
    /// Example: http://dictionary.reference.com/browse/SharpEcho would lookup the word SharpEcho
    /// 
    /// We look for something in the response that gives us a clear indication whether the
    /// word is spelled correctly or not
    /// </summary>
    public class DictionaryDotComSpellChecker : ISpellChecker
    {
        const string BASEURL = "https://dictionary.reference.com/browse/";
        public bool Check(string word)
        {
            string res = this.ReadWeb(BASEURL + word);
            if (res == "404") return false;
            return true;
        }

        private string ReadWeb(string url) {
            string result = "";
            ServicePointManager.Expect100Continue = true;
            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls
                   | SecurityProtocolType.Tls11
                   | SecurityProtocolType.Tls12
                   | SecurityProtocolType.Ssl3;

            WebClient client = new WebClient();
            client.Headers.Add("user-agent", "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.2; .NET CLR 1.0.3705;)");
            try {
                Stream data = client.OpenRead(url);
                StreamReader reader = new StreamReader(data);
                result = reader.ReadToEnd();
                data.Close();
                reader.Close();
            }
            catch (Exception ex) {
                if (ex.Message.Contains("404")) {
                    result = "404";
                }
            }
            return result;
        }
    }
}
